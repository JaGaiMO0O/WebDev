import { users } from "./Warframes.js";


    export const users = [
            { username: 'admin', password: '1234', role: 'admin' },
            { username: 'user1', password: '123', role: 'user' }
        ];


// function checkValid(form) {
//     if (form.username.value == "admin" && form.password.value == "adminpassword") {
//         return true;
//     } else if (form.username.value == "user1" && form.password.value == "userpassword") {
//         return true;
//     } else {
//         alert ("Incorrect Password or User")
//         return false
//     }
//}
