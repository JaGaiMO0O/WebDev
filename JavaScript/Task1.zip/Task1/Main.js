import { frames } from "./Warframes.js";




function createGenderDropdown() {
    const dropdownContainer = document.createElement('div');
    dropdownContainer.className = 'custom-dropdown';

    const dropdownBtn = document.createElement('button');
    dropdownBtn.className = 'dropdown-toggle';
    dropdownBtn.textContent = 'Filter by Gender';
    dropdownContainer.appendChild(dropdownBtn);

    const dropdownMenu = document.createElement('div');
    dropdownMenu.className = 'dropdown-menu';

    const options = ['All', 'Male', 'Female'];
    options.forEach(option => {
        const menuItem = document.createElement('div');
        menuItem.className = 'dropdown-item';
        menuItem.textContent = option;
        menuItem.dataset.gender = option;
        menuItem.addEventListener('click', () => {
            dropdownBtn.textContent = option;
            filterByGender(option);
            dropdownMenu.classList.remove('show');
        });
        dropdownMenu.appendChild(menuItem);
    });

    dropdownContainer.appendChild(dropdownMenu);


    dropdownBtn.addEventListener('click', () => {
        dropdownMenu.classList.toggle('show');
    });


    document.addEventListener('click', (e) => {
        if (!dropdownContainer.contains(e.target)) {
            dropdownMenu.classList.remove('show');
        }
    });

    document.querySelector('.inputs').appendChild(dropdownContainer);
}

function renderFrames(framesToRender = frames) {
    const grid = document.getElementById('table');
    grid.innerHTML = '';

    framesToRender.forEach((frame) => {
        grid.innerHTML += `
        <div class="WarFrame" id="${frame.id}">
            <img src="${frame.image}">
            <span>Name: ${frame.name}</span>
            <span>Gender: ${frame.gender}</span>
        </div>
        `;
    });
}

function filterByGender(gender) {
    const filtered = gender === 'All'
        ? frames
        : frames.filter(frame => frame.gender === gender);
    // renderFrames(filtered);
    return (filtered);
}

const genderFilter = filterByGender();

function filterFrames() {
    const nameSearch = document.getElementById('name').value.toLowerCase();

    const filteredName = frames.filter(frame => {
        const matchesName = frame.name.toLowerCase().includes(nameSearch);
        return matchesName;
    });

    renderFrames(filteredName);
}



function setupEventListeners() {
    document.getElementById('name').addEventListener('input', filterFrames);
}

document.addEventListener('DOMContentLoaded', () => {
    createGenderDropdown();
    renderFrames(genderFilter);
    setupEventListeners();
});



