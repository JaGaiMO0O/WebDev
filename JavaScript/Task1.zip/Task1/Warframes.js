export const frames = [
    {
        id: "1M",
        image: "Ash.png",
        name: "Ash",
        gender: "Male"
    },
    {
        id: "1F",
        image: "Saryn.png",
        name: "Saryn",
        gender: "Female"
    },
    {
        id: "2M",
        image: "Frost.png",
        name: "Frost",
        gender: "Male"
    },
    {
        id: "2F",
        image: "Mag.png",
        name: "Mag",
        gender: "Female"
    },
    {
        id: "3M",
        image: "Volt.png",
        name: "Volt",
        gender: "Male"
    },
    {
        id: "3F",
        image: "Nova.png",
        name: "Nova",
        gender: "Female"
    }
]